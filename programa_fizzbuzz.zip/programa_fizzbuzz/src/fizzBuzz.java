public interface fizzBuzz {
    public static void numerosFizzBuzz(int numeroIterado){
        
    }

}
