public interface fizzBuzz {
    void print (int from , int to);

}
