public interface fizzBuzz {
    /**
     * Refactorización  
     * Simplificación de llamadas de métodos
     * Método de cambio de nombre
     */
     void imprimirNumeros (int from , int to);

     
}
