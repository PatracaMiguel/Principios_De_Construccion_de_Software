
public class App extends ConsoleBasedFizzBuzz {
    public static void main(String[] args) throws Exception {
        fizzBuzz fizzBuzz = new ConsoleBasedFizzBuzz();
        fizzBuzz.imprimirNumeros(1, 100);
    }
    
}